function redirectHome() {
    window.location.href = 'home.php';
}

function redirectAboutUs() {
    window.location.href = 'about us.php';
}

function redirectProducts() {
    window.location.href = 'products.php';
}

function redirectContactUs() {
    window.location.href = 'contact us.php';
}

function redirectToProductDetails() {
    window.location.href = 'product details.php';
}

